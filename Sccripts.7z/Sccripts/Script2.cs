using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Script2 : MonoBehaviour
{
    private void Start() 
    {
        
    }
    public void ButtonClick()
    {
        System.Random rnd = new System.Random();
        int a = rnd.Next(1,100);
        int b = 0;
        if (a <40){
            b = 5;
        }
        if (a>80){
            b = 6;
        }
        if (a>40 && a<50){
            b = 12;
        }
        if (a>50 && a<80){
            b = 3;
        }
        if (a == 50){
            b = 4;
        }
        SceneManager.LoadScene(b);
    }
}
