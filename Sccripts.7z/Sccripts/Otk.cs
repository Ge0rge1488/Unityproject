using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Otk : MonoBehaviour
{
    public void ag(){
        SceneManager.LoadScene(2);
    }
}
