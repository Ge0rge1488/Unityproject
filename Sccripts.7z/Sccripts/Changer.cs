using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Changer : MonoBehaviour
{
    public void g()
    {
        SceneManager.LoadScene(2);
    }
}