using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class HO : MonoBehaviour
{
    public void zxc()
    {
        SceneManager.LoadScene(7);
    }
}
