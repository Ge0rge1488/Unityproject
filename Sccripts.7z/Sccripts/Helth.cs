using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Helth : MonoBehaviour
{
    public Image bar;
    public float maxHealth = 100f;
    void Starts()
    {
        bar.fillAmount = 0.1f;
    }
    void Update()
    {

    }
}